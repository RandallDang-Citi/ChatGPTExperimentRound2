import React from 'react'
import { Table } from 'antd'
import { Select } from 'antd'

const { Option } = Select

export default class COpilotTest extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            listOfData: [],
            listOfColumn: [],
            listOfDataNew: [],
            pagination: {},
            loading: false,
            search: '',
            filter: '',
            sort: '',
            page: 1,
            pageSize: 10,
            accountList: [],
        }
    }

    componentDidMount() {
        // init list of column: Transaction Reference, Value Date, Currency, amount, Benerficiary Name, account Name    
        const listOfColumn = [
            {
                title: 'Transaction Reference',
                dataIndex: 'transactionReference',
                key: 'transactionReference',
                sorter: true,
                render: text => <a>{text}</a>,
            },
            {
                title: 'Value Date',
                dataIndex: 'valueDate',
                key: 'valueDate',
                sorter: true,
            },
            {

                title: 'Currency',
                dataIndex: 'currency',
                key: 'currency',
                sorter: true,
            },
            {
                title: 'Amount',
                dataIndex: 'amount',
                key: 'amount',
                sorter: true,
            },

            {
                title: 'Benerficiary Name',
                dataIndex: 'benerficiaryName',
                key: 'benerficiaryName',
                sorter: true,
            },
            {
                title: 'account Name',
                dataIndex: 'accountName',
                key: 'accountName',
                sorter: true,
            },
        ]
        this.setState({
            listOfColumn: listOfColumn,
        })
        // init list of data: random data
        const listOfData = [
            {
                key: '1',
                transactionReference: 'John Brown',
                valueDate: '2019-01-01',
                currency: 'USD',
                amount: '100',
                benerficiaryName: 'New York No. 1 Lake Park',
                accountName: 'New York No. 1 Lake Park',

            },
            {
                key: '2',
                transactionReference: 'Jim Green',
                valueDate: '2019-01-01',
                currency: 'USD',
                amount: '100',
                benerficiaryName: 'London No. 1 Lake Park',
                accountName: 'London No. 1 Lake Park',
            },
            {
                key: '3',
                transactionReference: 'Joe Black',
                valueDate: '2019-01-01',
                currency: 'USD',
                amount: '100',
                benerficiaryName: 'Sidney No. 1 Lake Park',
                accountName: 'Sidney No. 1 Lake Park',

            },
            {
                key: '4',
                transactionReference: 'John Brown',
                valueDate: '2019-01-01',
                currency: 'USD',
                amount: '100',
                benerficiaryName: 'New York No. 1 Lake Park',
                accountName: 'New York No. 1 Lake Park',

            },
            {
                key: '5',
                transactionReference: 'Jim Green',
                valueDate: '2019-01-01',
                currency: 'USD',
                amount: '100',
                benerficiaryName: 'London No. 1 Lake Park',

                accountName: 'London No. 1 Lake Park',
            },
            {
                key: '6',
                transactionReference: 'Joe Black',
                valueDate: '2019-01-01',
                currency: 'USD',
                amount: '100',
                benerficiaryName: 'Sidney No. 1 Lake Park',
                accountName: 'Sidney No. 1 Lake Park',

            },
            {
                key: '7',
                transactionReference: 'John Brown',
                valueDate: '2019-01-01',
                currency: 'USD',
                amount: '100',
                benerficiaryName: 'New York No. 1 Lake Park',

                accountName: 'New York No. 1 Lake Park',
            },
            {
                key: '8',
                transactionReference: 'Jim Green',
                valueDate: '2019-01-01',
                currency: 'USD',
                amount: '100',
                benerficiaryName: 'London No. 1 Lake Park',

                accountName: 'London No. 1 Lake Park',

            }
        ];
        this.setState({
            listOfData: listOfData,
            listOfDataNew: listOfData
        })
        // init pagination
        const pagination = {

            showSizeChanger: true,
            showQuickJumper: true,
            pageSize: 10,
            total: 200
        }          
        this.setState({
            pagination: pagination,
        })

        const accountList = [
            'New York No. 1 Lake Park',
            'London No. 1 Lake Park',
            'Sidney No. 1 Lake Park',
        ];
        this.setState({
            accountList: accountList,
        })

    }

    handleTableChange = (pagination, filters, sorter) => {
        console.log(pagination)
        console.log(filters)
        console.log(sorter)
        this.setState({
            page: pagination.current,
            pageSize: pagination.pageSize,
            sort: sorter.field,
            filter: filters,
        })
        this.fetch({
            page: pagination.current,
            pageSize: pagination.pageSize,
            sort: sorter.field,
            filter: filters,
        })
    }


    handleChange = (value) => {
        // filter data by account name
        var listOfData = this.state.listOfData
        var listOfDataNew = []
        for (var i = 0; i < listOfData.length; i++) {
            if (listOfData[i].accountName === value) {
                listOfDataNew.push(listOfData[i])
            }
        }
        this.setState({
            listOfDataNew: listOfDataNew,
        })
        
        console.log(`selected ${value}`);
    }

    handleSearch = (value) => {
        console.log('search: ' + value)
    }



    fetch = (params = {}) => {
        // this.setState({ loading: true })
        // fetch('https://randomuser.me/api/?results=10')
        //     .then(response => response.json())
        //     .then(data => {
        //         console.log(data)
        //         const pagination = { ...this.state.pagination }

        //         pagination.total = 200
        //         this.setState({
        //             loading: false,
        //             listOfData: data.results,
        //             pagination,
        //         })
        //     })
    }

    render() {
        return (
            <div style={{width: '100%', height: '80%'}}>
                <Select
                    showSearch
                    style={{ width: 200 }}
                    placeholder="Select by account name"
                    optionFilterProp="children"
                    onChange={this.handleChange}
                    onSearch={this.handleSearch}
                    filterOption={(input, option) =>
                        option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                    }
                >
                    {this.state.accountList.map((item, index) => {
                        return (
                            <Option key={index} value={item}>{item}</Option>
                        )
                    })}
                </Select>
                
                <Table
                    columns={this.state.listOfColumn}
                    dataSource={this.state.listOfDataNew}
                    pagination={this.state.pagination}
                    loading={this.state.loading}
                    onChange={this.handleTableChange}
                >
                </Table>
            </div>

        )


    }
}
