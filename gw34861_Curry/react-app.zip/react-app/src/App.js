import './App.css';
import COpilotTest from './copilotTest';

function App() {

  return (
    <div className="App">
      <header className="App-header">
        <COpilotTest />
      </header>
    </div>
  );
}

export default App;
