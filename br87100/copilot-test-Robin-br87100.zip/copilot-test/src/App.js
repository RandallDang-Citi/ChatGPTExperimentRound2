import React, { useState, useEffect } from "react";
import { useTheme } from "@mui/material/styles";
import { DataGrid } from "@mui/x-data-grid";
import MenuItem from "@mui/material/MenuItem";
import { Select, Table, Button } from "@mui/material";

import "./App.css";
const mockData = require("./mock/testData.json");

const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: 200,
      width: 500,
    },
  },
};

function App() {
  const pageNum = 5
  const theme = useTheme();
  const [selAmount, setSelAmount] = React.useState([]);
  const [allData, setAllData] = useState([]); // all data from mockData
  const [filterData, setFilterData] = useState([]);
  const [data, setData] = useState([]);
  const [dropList, setDropList] = useState([]);
  const [pageSize, setPageSize] = useState(0);
  const [curPage, setCurPage] = useState(0); // current page number

  useEffect(() => {
    const data = mockData.map((row, index) => {
      return {
        id: index,
        ...row,
      };
    });
    setAllData(data)
    setFilterData(data);
    getDopList(data);
    setPageSize(getPageNums(data));
  }, []);

  useEffect(() => {
    // handleNewPage(0)
  }, [allData])

  const handleChange = (event) => {
    const value = event.target.value
    // value 是一个数组， 过滤出data中包含value的数据
    const filterData = allData.filter((row) => {
      return value.includes(row.paymentAmount);
    });

    // 设置 data 为过滤后的数据
    setFilterData(filterData);
    setSelAmount(value)
    setPageSize(getPageNums(filterData));
  };

  useEffect(() => {
    const newData = filterData.slice(curPage * pageNum, (curPage + 1) * pageNum);
    setData(newData)
  }, [filterData, curPage]);

  const getDopList = (data) => {
    // get paymentAmount key from data
    const dropList = data.map((row) => {
      return row.paymentAmount;
    });
    // 去重并 set dropList
    setDropList([...new Set(dropList)]);
  };

  const getPageNums = (data) => {
    const len = data.length;
    const nums = Math.ceil(len / 5);
    return nums;
  };

  const handleNewPage = (i) => {
    setCurPage(i)
  }

  const pageItems = () => {
    const items = [];
    for (let i = 0; i < pageSize - 1; i++) {
      items.push(
        <Button key={i} value={i + 1} className="button" onClick={()=>{handleNewPage(i)} } >
          {i + 1}
        </Button>
      );
    }
    return items
  }

  const columns = [
    {
      field: "transactionReferenceNumber",
      headerName: "Transactionb Reference",
      width: 200,
    },
    { field: "valueDate", headerName: "Value Date", width: 200 },
    {
      field: "paymentAmount",
      headerName: "Last name",
      type: "number",
      width: 130,
    },
    { field: "paymentCurrency", headerName: "Payment Currency", width: 200 },
    {
      field: "beneficiaryName",
      headerName: "Full name",
      description: "This column has a value getter and is not sortable.",
      width: 200,
    },
    {
      field: "accountName",
      headerName: "Age",
      type: "number",
      width: 200,
    },
  ];

  function getStyles(name, personName, theme) {
    return {
      fontWeight:
        personName.indexOf(name) === -1
          ? theme.typography.fontWeightRegular
          : theme.typography.fontWeightMedium,
    };
  }

  return (
    <div id="table">
      <div>Amounts:</div>
      <div>
        <Select
          labelId="demo-multiple-name-label"
          id="demo-multiple-name"
          multiple
          value={selAmount}
          onChange={handleChange}
          // input={<OutlinedInput label="Name" />}
          MenuProps={MenuProps}
        >
          {dropList.map((name) => (
            <MenuItem
              key={name}
              value={name}
              style={getStyles(name, selAmount, theme)}
            >
              {name}
            </MenuItem>
          ))}
        </Select>
      </div>
      {
        // code by copilot
      }
      <div style={{ height: 400, width: "100%" }}>
        <DataGrid
          rows={data}
          columns={columns}
          // initialState={{
          //   pagination: {
          //     paginationModel: { page: 5, pageSize: 6 },
          //   },
          // }}
          // pageSizeOptions={[5, 6]}
        />
      </div>
      <div className="flex">
        {
          pageItems()
        }
      </div>
    </div>
  );
}

export default App;
