package com.citi.copilot.entity;

import lombok.Data;

@Data
public class RegistrationEntity {
    private String applicationCsi;
    private String applicationName;
}
