package com.citi.copilot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CopilotApplicationTests {

	@Test
	void contextLoads() {
	}

}
